function mode() {
    
    const html = document

    html.classList = mode
}